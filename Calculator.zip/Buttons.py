from tkinter import *


calgui = Tk()
calgui.title("Caculator")
canvas = Canvas(calgui, height=300, width=20)
canvas.grid(columnspan=4, rowspan=7 )
equation = StringVar()
# txt_box = Text(calgui,height=5, width=30, borderwidth=10, font="Raleway")
# txt_box.grid(columnspan=4,column=0, row=0)
txt_box = Entry(calgui, textvariable=equation, font="Raleway", borderwidth=6)
txt_box.grid(column=0, row=0, columnspan=4,ipadx=80, ipady=30)
exp = ""

def press(num):
    global exp
    exp = exp + str(num)
    equation.set(exp)


def equalpress():

    try:
        global exp
        total = str(eval(exp))
        equation.set(total)
        exp = ""
    except:
        equation.set(" error ")
        exp = ""

def clearing():
    global exp
    exp = ""
    equation.set("")

def button1():
    btn1_txt = StringVar()
    btn1_btn = Button(calgui, borderwidth=6 ,textvariable=btn1_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(1))
    btn1_txt.set("1")
    btn1_btn.grid(column=0, row=1)

def button2():
    btn2_txt = StringVar()
    btn2_btn = Button(calgui, borderwidth=6, textvariable=btn2_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(2))
    btn2_txt.set("2")
    btn2_btn.grid(column=1, row=1)

def button3():
    btn3_txt = StringVar()
    btn3_btn = Button(calgui, borderwidth=6, textvariable=btn3_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(3))
    btn3_txt.set("3")
    btn3_btn.grid(column=2, row=1)

def button4():
    btn4_txt = StringVar()
    btn4_btn = Button(calgui, borderwidth=6, textvariable=btn4_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(4))
    btn4_txt.set("4")
    btn4_btn.grid(column=0, row=2)

def button5():
    btn5_txt = StringVar()
    btn5_btn = Button(calgui, borderwidth=6, textvariable=btn5_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(5))
    btn5_txt.set("5")
    btn5_btn.grid(column=1, row=2)

def button6():
    btn6_txt = StringVar()
    btn6_btn = Button(calgui, borderwidth=6, textvariable=btn6_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(6))
    btn6_txt.set("6")
    btn6_btn.grid(column=2, row=2)

def button7():
    btn7_txt = StringVar()
    btn7_btn = Button(calgui, borderwidth=6, textvariable=btn7_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(7))
    btn7_txt.set("7")
    btn7_btn.grid(column=0, row=3)

def button8():
    btn8_txt = StringVar()
    btn8_btn = Button(calgui, borderwidth=6, textvariable=btn8_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(8))
    btn8_txt.set("8")
    btn8_btn.grid(column=1, row=3)

def button9():
    btn9_txt = StringVar()
    btn9_btn = Button(calgui, borderwidth=6, textvariable=btn9_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(9))
    btn9_txt.set("9")
    btn9_btn.grid(column=2, row=3)

def button0():
    btn0_txt = StringVar()
    btn0_btn = Button(calgui, borderwidth=6, textvariable=btn0_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press(0))
    btn0_txt.set("0")
    btn0_btn.grid(column=1, row=4)

def buttonmulti():
    btnmulti_txt = StringVar()
    btnmulti_btn = Button(calgui, borderwidth=6, textvariable=btnmulti_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press("*"))
    btnmulti_txt.set("x")
    btnmulti_btn.grid(column=3, row=1)

def buttonsum():
    btnsum_txt = StringVar()
    btnsum_btn = Button(calgui, borderwidth=6, textvariable=btnsum_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press("+"))
    btnsum_txt.set("+")
    btnsum_btn.grid(column=3, row=3)

def buttonsub():
    btnsub_txt = StringVar()
    btnsub_btn = Button(calgui, borderwidth=6, textvariable=btnsub_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press("-"))
    btnsub_txt.set("-")
    btnsub_btn.grid(column=3, row=2)

def buttondiv():
    btndiv_txt = StringVar()
    btndiv_btn = Button(calgui, borderwidth=6, textvariable=btndiv_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press("/"))
    btndiv_txt.set("/")
    btndiv_btn.grid(column=3, row=4)

def buttonequal():
    btnequ_txt = StringVar()
    btnequ_btn = Button(calgui, borderwidth=6, textvariable=btnequ_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :equalpress())
    btnequ_txt.set("=")
    btnequ_btn.grid(column=2, row=4)

def buttonC():
    btnres_txt = StringVar()
    btnres_btn = Button(calgui, borderwidth=6, textvariable=btnres_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :clearing())
    btnres_txt.set("C")
    btnres_btn.grid(column=0, row=4)

def decimal():
    btndec_txt = StringVar()
    btndec_btn = Button(calgui, borderwidth=6, textvariable=btndec_txt, bg="black", fg="white", font="Raleway", width=5, command=lambda :press("."))
    btndec_txt.set(".")
    btndec_btn.grid(column=0, row=6)






