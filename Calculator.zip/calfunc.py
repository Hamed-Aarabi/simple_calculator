import math
def calfunc(num1,num2, op):
    if op == "+":
        return num1 + num2
    elif op == "-":
        return num1 - num2
    elif op == "*":
        return num1 * num2
    elif op == "/":
        return num1 / num2
    elif op == "^":
        return math.pow(num1,num2)
    elif op == "!":
        return math.factorial(num1), math.factorial(num2)
    elif op == "log":
        return math.log(num1), math.log(num2)


