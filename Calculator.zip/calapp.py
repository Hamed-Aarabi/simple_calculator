from tkinter import *
from Buttons import *

gui = calgui

txtbox = txt_box





button1 = button1()
button2 = button2()
button3 = button3()
button4 = button4()
button5 = button5()
button6 = button6()
button7 = button7()
button8 = button8()
button9 = button9()
button0 = button0()
buttonC = buttonC()
buttondec = decimal()
buttonsum = buttonsum()
buttonsub = buttonsub()
buttondiv = buttondiv()
buttonmulti = buttonmulti()
buttonequal = buttonequal()














gui.mainloop()
